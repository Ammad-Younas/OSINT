from setuptools import setup, find_packages

setup(
    name="GetInformation",
    version="1.1",
    author="Ammad Younas",
    author_email="<ammadyounas837@gmai.com>",
    packages=find_packages(),
    install_requires=[
        # Add your dependencies here
        # For example: 'numpy', 'requests'
    ],
)